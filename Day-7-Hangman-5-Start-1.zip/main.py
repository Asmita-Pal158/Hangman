#Step 5

import random
from hangman_words import word_list 
from hangman_art import stages
from hangman_art import logo
print(logo)
#TODO-1: - Update the word list to use the 'word_list' from hangman_words.py
#Delete this line: word_list = ["ardvark", "baboon", "camel"]
chsnwrd = random.choice(word_list)
wrdlen = len(chsnwrd)

end_of_game = False
lives = 6

#TODO-3: - Import the logo from hangman_art.py and print it at the start of the game.

#Testing code
print(f'Pssst, the solution is {chsnwrd}.')

#Create blanks
display = []
for _ in range(wrdlen):
    display += "_"
#TODO-4: - If the user has entered a letter they've already guessed, print the letter and let them know.
  #TODO-5: - If the letter is not in the chosen_word, print out the letter and let them know it's not in the word.
f=0
while not end_of_game:
  if "_" not in display:  
    f=1
    break
    
  if lives>0:
    c=0
    guess = input("Guess a letter").lower()
    for position in range(wrdlen):
       letter = chsnwrd[position]
       if letter == guess:
          if display[position]== guess:
            print(f"lettter{guess} is already been guessed")
            c=1
          else:  
            display[position] = letter
            c=1
          
    if c!=1:
      print(f"The letter, {guess} is not in the word")
      lives-=1
      print(stages[lives])
    print(display)  
  else:  
    if "_" not in display:
      print("CONGRATULATIONS!! You won")
    else:
      print("You loose\n GAME OVER!!")
      break
  


if f ==1 :
  print ("CONGRATULATIONS!! you won")